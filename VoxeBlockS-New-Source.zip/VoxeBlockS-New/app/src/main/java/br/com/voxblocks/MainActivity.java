package br.com.voxblocks;

import android.app.*;import android.os.*;import android.content.*;import android.opengl.*;import android.view.*;import android.graphics.*;import java.nio.*;import java.util.*;

public class MainActivity extends Activity{
  GameView game;
  @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN); game=new GameView(this); setContentView(game);}
  @Override protected void onPause(){super.onPause(); game.pauseGame();}
  @Override protected void onResume(){super.onResume(); if(game!=null) game.resumeGame();}
}

class GameView extends GLSurfaceView{
  final GameRenderer r;
  float lookX,lookY; long last;
  GameView(Context c){super(c); setEGLContextClientVersion(2); r=new GameRenderer(c); setRenderer(r); setRenderMode(RENDERMODE_CONTINUOUSLY); last=System.nanoTime();}
  void pauseGame(){r.save();}
  void resumeGame(){last=System.nanoTime();}
  @Override public boolean onTouchEvent(MotionEvent e){
    int act=e.getActionMasked(); int pc=e.getPointerCount();
    if(act==MotionEvent.ACTION_DOWN||act==MotionEvent.ACTION_POINTER_DOWN){return true;}
    if(act==MotionEvent.ACTION_MOVE){
      if(pc>=1){int i=pc-1; float x=e.getX(i),y=e.getY(i); if(x>getWidth()*0.48f){ if(last>0){float dx=x-lookX,dy=y-lookY; r.yaw+=dx*0.20f; r.pitch=clamp(r.pitch-dy*0.14f,-82,82);} lookX=x;lookY=y; } else { float cx=getWidth()*0.18f,cy=getHeight()*0.68f; r.moveX=clamp((x-cx)/(getWidth()*0.16f),-1,1); r.moveZ=clamp((cy-y)/(getHeight()*0.16f),-1,1); } } return true; }
    if(act==MotionEvent.ACTION_UP||act==MotionEvent.ACTION_CANCEL||act==MotionEvent.ACTION_POINTER_UP){r.moveX*=0.0f;r.moveZ*=0.0f; return true;} return true;
  }
  static float clamp(float v,float a,float b){return Math.max(a,Math.min(b,v));}
}

class GameRenderer implements GLSurfaceView.Renderer{
  final Context ctx; final Random rnd=new Random(1337); final int WORLD=48, H=18; final byte[][][] blocks=new byte[WORLD][H][WORLD];
  final HashMap<String,Byte> edits=new HashMap<>(); final float[] player={24.5f,8.2f,24.5f}; float vy=0,yaw=45,pitch=-18; float moveX,moveZ; boolean crouch,sprint,third,onGround; int jumps; float dashT; int selected=0; final int[] inv={64,32,24,16,8,0};
  int program,aPos,aCol,uMvp; FloatBuffer vb,cb; int vCount; boolean dirty=true; long saveAt;
  final String[] names={"Grama","Pedra","Terra","Areia","Cristal","Madeira"};
  GameRenderer(Context c){ctx=c; load();}
  @Override public void onSurfaceCreated(GL10 gl,EGLConfig cfg){String vs="attribute vec3 aPos;attribute vec4 aCol;uniform mat4 uMvp;varying vec4 vCol;void main(){gl_Position=uMvp*vec4(aPos,1.0);vCol=aCol;}"; String fs="precision mediump float;varying vec4 vCol;void main(){gl_FragColor=vCol;}"; int v=compile(GLES20.GL_VERTEX_SHADER,vs),f=compile(GLES20.GL_FRAGMENT_SHADER,fs);program=GLES20.glCreateProgram();GLES20.glAttachShader(program,v);GLES20.glAttachShader(program,f);GLES20.glLinkProgram(program);aPos=GLES20.glGetAttribLocation(program,"aPos");aCol=GLES20.glGetAttribLocation(program,"aCol");uMvp=GLES20.glGetUniformLocation(program,"uMvp");GLES20.glEnable(GLES20.GL_DEPTH_TEST);GLES20.glClearColor(.55f,.78f,1f,1); generate();}
  int compile(int t,String s){int id=GLES20.glCreateShader(t);GLES20.glShaderSource(id,s);GLES20.glCompileShader(id);return id;}
  @Override public void onSurfaceChanged(GL10 gl,int w,int h){GLES20.glViewport(0,0,w,h);}
  @Override public void onDrawFrame(GL10 gl){GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT|GLES20.GL_DEPTH_BUFFER_BIT); update(0.016f); if(dirty) buildMesh(); drawWorld(); drawHud(); if(System.currentTimeMillis()-saveAt>5000)save();}
  void update(float dt){
    float len=(float)Math.sqrt(moveX*moveX+moveZ*moveZ); float mx=moveX,mz=moveZ; if(len>1){mx/=len;mz/=len;}
    float speed=sprint?5.0f:2.7f; if(crouch)speed*=0.55f;
    float ry=(float)Math.toRadians(yaw); float fx=(float)Math.sin(ry),fz=(float)Math.cos(ry); float rx=fz,rz=-fx;
    player[0]+= (rx*mx+fx*mz)*speed*dt; player[2]+=(rz*mx+fz*mz)*speed*dt;
    player[0]=clamp(player[0],1,WORLD-2);player[2]=clamp(player[2],1,WORLD-2);
    vy-=12.5f*dt; player[1]+=vy*dt; float ground=surface((int)player[0],(int)player[2]); if(player[1]<=ground+1.75f){player[1]=ground+1.75f;vy=0;onGround=true;jumps=0;} else onGround=false;
    if(dashT>0){player[0]+=Math.sin(ry)*7*dt;player[2]+=Math.cos(ry)*7*dt;dashT-=dt;}
  }
  void jump(){if(onGround||jumps<2){vy=5.2f;onGround=false;jumps++;}}
  void dash(){dashT=.22f;}
  void generate(){for(int x=0;x<WORLD;x++)for(int z=0;z<WORLD;z++){int h=surface(x,z);for(int y=0;y<H;y++){byte b=0;if(y<h-3)b=2;else if(y<h-1)b=3;else if(y==h-1)b=1;else if(y<3)b=2;blocks[x][y][z]=b;}}}
  int surface(int x,int z){double n=Math.sin(x*.21)+Math.cos(z*.18)+.45*Math.sin((x+z)*.08);return Math.max(3,Math.min(H-3,7+(int)Math.round(n*2)));}
  boolean solid(int x,int y,int z){return x>=0&&z>=0&&y>=0&&x<WORLD&&z<WORLD&&y<H&&blocks[x][y][z]!=0;}
  void buildMesh(){ArrayList<Float> vs=new ArrayList<>(),cs=new ArrayList<>(); for(int x=0;x<WORLD;x++)for(int y=0;y<H;y++)for(int z=0;z<WORLD;z++){byte b=blocks[x][y][z];if(b==0)continue; for(int f=0;f<6;f++)if(!solid(x+dx(f),y+dy(f),z+dz(f)))face(vs,cs,x,y,z,f,b);} float[] va=new float[vs.size()],ca=new float[cs.size()];for(int i=0;i<va.length;i++)va[i]=vs.get(i);for(int i=0;i<ca.length;i++)ca[i]=cs.get(i);vb=ByteBuffer.allocateDirect(va.length*4).order(ByteOrder.nativeOrder()).asFloatBuffer();vb.put(va).position(0);cb=ByteBuffer.allocateDirect(ca.length*4).order(ByteOrder.nativeOrder()).asFloatBuffer();cb.put(ca).position(0);vCount=va.length/3;dirty=false;}
  int dx(int f){return new int[]{0,0,-1,1,0,0}[f];}int dy(int f){return new int[]{1,-1,0,0,0,0}[f];}int dz(int f){return new int[]{0,0,0,0,1,-1}[f];}
  void face(ArrayList<Float>v,ArrayList<Float>c,int x,int y,int z,int f,byte b){float[][] q={{0,1,0,0,1,1,1,1,1,1,1,0},{0,0,1,1,0,1,1,1,1,0,0,0},{0,0,0,0,1,0,1,1,0,1,1,1},{1,0,1,1,1,1,0,1,0,0,0,1},{0,0,1,0,1,1,1,1,1,1,0,0},{0,0,0,1,0,1,1,1,1,0,1,0}};float[] sh=shade(f,b);int[] idx={0,1,2,0,2,3};for(int i:idx){int k=i*3;v.add(x+q[f][k]);v.add(y+q[f][k+1]);v.add(z+q[f][k+2]);c.add(sh[0]);c.add(sh[1]);c.add(sh[2]);c.add(1f);}}
  float[] shade(int f,byte b){float base=b==1?0.62f:b==2?0.38f:b==3?.55f:b==4?.78f:.72f;float s=(f==0?1.08f:f==1?.72f:.88f);return new float[]{Math.min(1,base*s),Math.min(1,base*s*.92f),Math.min(1,base*s*.82f)};}
  void drawWorld(){if(vb==null)return;float[] proj=new float[16],view=new float[16],mvp=new float[16];float aspect=1.0f;if(ctx instanceof Activity){android.graphics.Point p=new android.graphics.Point();((Activity)ctx).getWindowManager().getDefaultDisplay().getSize(p);aspect=p.x/(float)p.y;}Matrix.frustumM(proj,0,-aspect,aspect,-1,1,1,80);float ry=(float)Math.toRadians(yaw),rp=(float)Math.toRadians(pitch);float cx=player[0],cy=player[1]+.55f,cz=player[2];if(third){cx-=Math.sin(ry)*4.3f;cz-=Math.cos(ry)*4.3f;cy+=.9f;}float tx=cx+(float)Math.sin(ry)*10,ty=cy+(float)Math.sin(rp)*10,tz=cz+(float)Math.cos(ry)*10;Matrix.setLookAtM(view,0,cx,cy,cz,tx,ty,tz,0,1,0);Matrix.multiplyMM(mvp,0,proj,0,view,0);GLES20.glUseProgram(program);vb.position(0);cb.position(0);GLES20.glEnableVertexAttribArray(aPos);GLES20.glEnableVertexAttribArray(aCol);GLES20.glVertexAttribPointer(aPos,3,GLES20.GL_FLOAT,false,0,vb);GLES20.glVertexAttribPointer(aCol,4,GLES20.GL_FLOAT,false,0,cb);GLES20.glUniformMatrix4fv(uMvp,1,false,mvp,0);GLES20.glDrawArrays(GLES20.GL_TRIANGLES,0,vCount);GLES20.glDisableVertexAttribArray(aPos);GLES20.glDisableVertexAttribArray(aCol);}
  void drawHud(){/* HUD is implemented in the Android view layer in the next UI pass. */}
  void breakOrPlace(boolean place){int[] t=ray();if(t==null)return;if(place){int x=t[0],y=t[1],z=t[2];int bx=x+(int)Math.round(-Math.sin(Math.toRadians(yaw))),bz=z+(int)Math.round(-Math.cos(Math.toRadians(yaw))); if(inv[selected]>0&&y>=0&&y<H&&bx>=0&&bz>=0&&bx<WORLD&&bz<WORLD&&blocks[bx][y][bz]==0){blocks[bx][y][bz]=(byte)(selected+1);inv[selected]--;dirty=true;}}else{if(solid(t[0],t[1],t[2])){blocks[t[0]][t[1]][t[2]]=0;inv[selected]++;dirty=true;}}}
  int[] ray(){double ry=Math.toRadians(yaw),rp=Math.toRadians(pitch);double dx=Math.sin(ry)*Math.cos(rp),dy=Math.sin(rp),dz=Math.cos(ry)*Math.cos(rp);for(float d=.2f;d<7;d+=.12f){int x=(int)Math.floor(player[0]+dx*d),y=(int)Math.floor(player[1]+dy*d),z=(int)Math.floor(player[2]+dz*d);if(solid(x,y,z))return new int[]{x,y,z};}return null;}
  void save(){saveAt=System.currentTimeMillis();ctx.getSharedPreferences("world",0).edit().putFloat("px",player[0]).putFloat("py",player[1]).putFloat("pz",player[2]).putFloat("yaw",yaw).apply();}
  void load(){android.content.SharedPreferences p=ctx.getSharedPreferences("world",0);player[0]=p.getFloat("px",24.5f);player[1]=p.getFloat("py",8.2f);player[2]=p.getFloat("pz",24.5f);yaw=p.getFloat("yaw",45);}
  float clamp(float v,float a,float b){return Math.max(a,Math.min(b,v));}
}
